package logic;

public class Cartao {
    private String numeroCartao;
    private String titularCartao;
    private int CVV;
    private int dataValidade;

    public String getNumeroCartao() {
        return numeroCartao;
    }

    
    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }
    
}

