package logic;

public class Pair {
    public  Banco banco;
    public Conta conta;

    public Pair(Banco banco, Conta conta) { 
        this.banco = banco;
        this.conta = conta;
    }

    
}