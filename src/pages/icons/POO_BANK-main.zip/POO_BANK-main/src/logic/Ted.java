package logic;

public interface Ted {
    void pagarComTed(double valor, int agencia, int numeroConta, int cpf);    
}