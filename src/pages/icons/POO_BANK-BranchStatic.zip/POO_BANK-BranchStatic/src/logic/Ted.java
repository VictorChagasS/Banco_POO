package logic;

public interface Ted {
    void transferenciaTed(Conta contaDestino, double valor) throws Exception;    
}